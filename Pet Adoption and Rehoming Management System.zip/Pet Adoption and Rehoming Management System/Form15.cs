﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace loadingBar
{
    public partial class Form15 : Form
    {
        public Form15()
        {
            InitializeComponent();
            btnClear.Click += new System.EventHandler(this.btnClear_Click);
            btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            dataGridView1_CellClick(this, new DataGridViewCellEventArgs(0, -1));
        }
        private readonly string connectionString = @"Data Source=LAPTOP-QNEEHTJU\SQLEXPRESS;Initial Catalog=Login;Integrated Security=True;Encrypt=False";

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Check for valid row index
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtPetID.Text = row.Cells["Pet_ID"].Value?.ToString() ?? ""; // Handle null values
                txtType.Text = row.Cells["Pet_Name"].Value?.ToString() ?? "";
                txtName.Text = row.Cells["Pet_owner"].Value?.ToString() ?? "";
                txtAge.Text = row.Cells["Bank_Acount"].Value?.ToString() ?? "";
                textBox1.Text = row.Cells["Bank"].Value?.ToString() ?? "";
                txtDisability.Text = row.Cells["Branch"].Value?.ToString() ?? "";
            }
        }


        private void pictureBox12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtPetID.Text = row.Cells["Pet_ID"].Value.ToString();
                txtType.Text = row.Cells["Pet_Name"].Value.ToString();
                txtName.Text = row.Cells["Pet_owner"].Value.ToString();
                txtAge.Text = row.Cells["Bank_Acount"].Value.ToString();
                textBox1.Text = row.Cells["Bank"].Value.ToString();
                txtDisability.Text = row.Cells["Branch"].Value.ToString();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int pet_ID = GeneratePetID();
            string type = txtType.Text.Trim();
            string name = txtName.Text.Trim();
            string age = txtAge.Text.Trim();
            string gender = textBox1.Text.Trim();
            string disability = txtDisability.Text.Trim();

            if (string.IsNullOrWhiteSpace(type) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(age) || string.IsNullOrEmpty(gender) || string.IsNullOrWhiteSpace(disability))
            {
                MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            string query = "INSERT INTO Table_Donation (Pet_ID, Pet_Name, Pet_owner, Bank_Acount, Bank, Branch) " +
           "VALUES (@Pet_ID, @Pet_Name, @Pet_owner, @Bank_Acount, @Bank, @Branch)";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Pet_ID", pet_ID);
                    cmd.Parameters.AddWithValue("@Pet_Name", type);
                    cmd.Parameters.AddWithValue("@Pet_owner", name);
                    cmd.Parameters.AddWithValue("@Bank_Acount", age);
                    cmd.Parameters.AddWithValue("@Bank", gender);
                    cmd.Parameters.AddWithValue("@Branch", disability);
        

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        LoadData();
                        ClearForm();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        private int GeneratePetID()
        {
            return GetMaxID() + 1;
        }

        private int GetMaxID()
        {
            int maxID = 0;
            string query = "SELECT MAX(Pet_ID) FROM Table_Donation";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            maxID = Convert.ToInt32(result);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }

            return maxID;
        }


        private void LoadData()
        {
            string query = "SELECT * FROM Table_Donation";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            txtPetID.Text = GeneratePetID().ToString(); 
            txtType.Clear();
            txtName.Clear();
            txtAge.Clear();
            textBox1.Clear();
            txtDisability.Clear();          
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtPetID.Text, out int petID))
            {
                string type = txtType.Text.Trim();
                string name = txtName.Text.Trim();
                string age = txtAge.Text.Trim();
                string gender = textBox1.Text.Trim();
                string disability = txtDisability.Text.Trim();
               
                if (string.IsNullOrWhiteSpace(type) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(age) || string.IsNullOrEmpty(gender) || string.IsNullOrWhiteSpace(disability))
                {
                    MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                string query = "UPDATE Table_Donation SET Pet_Name = @Pet_Name, Pet_owner = @Pet_owner, Bank_Acount = @Bank_Acount, Bank = @Bank, Branch = @Branch WHERE Pet_ID = @Pet_ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Pet_ID", petID);
                        cmd.Parameters.AddWithValue("@Pet_Name", type);
                        cmd.Parameters.AddWithValue("@Pet_owner", name);
                        cmd.Parameters.AddWithValue("@Bank_Acount", age);
                        cmd.Parameters.AddWithValue("@Bank", gender);
                        cmd.Parameters.AddWithValue("@Branch", disability);
                      
                        try
                        {
                            conn.Open();
                            cmd.ExecuteNonQuery();
                            LoadData();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid Pet ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                int petID = Convert.ToInt32(dataGridView1.Rows[selectedRowIndex].Cells["Pet_ID"].Value);

                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this pet?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dialogResult == DialogResult.Yes)
                {
                    // Delete the selected pet record from the database
                    string deleteQuery = "DELETE FROM Table_Donation WHERE Pet_ID = @petID";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@petID", petID);

                            try
                            {
                                conn.Open();
                                cmd.ExecuteNonQuery();
                                dataGridView1.Rows.RemoveAt(selectedRowIndex);
                                ResequencePetIDs();
                                LoadData();
                                MessageBox.Show("Pet deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error deleting pet: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            finally
                            {
                                conn.Close();
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResequencePetIDs()
        {
            List<int> remainingIDs = new List<int>();
            string getIDsQuery = "SELECT Pet_ID FROM Table_Donation ORDER BY Pet_ID";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(getIDsQuery, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                remainingIDs.Add(Convert.ToInt32(reader["Pet_ID"]));
                            }
                        }

                        int newID = 1;
                        foreach (int oldID in remainingIDs)
                        {
                            string updateQuery = "UPDATE Table_Donation SET Pet_ID = @newID WHERE Pet_ID = @oldID";
                            using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                            {
                                updateCmd.Parameters.AddWithValue("@newID", newID);
                                updateCmd.Parameters.AddWithValue("@oldID", oldID);
                                updateCmd.ExecuteNonQuery();
                            }
                            newID++;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error re-sequencing Pet IDs: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        private void Form15_Load(object sender, EventArgs e)
        {
            txtPetID.Text = GeneratePetID().ToString();
            LoadData();
                
        }

        private void label14_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
    }
}
