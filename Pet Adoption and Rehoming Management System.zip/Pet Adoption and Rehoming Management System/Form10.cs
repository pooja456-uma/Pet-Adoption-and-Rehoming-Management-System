﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace loadingBar
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
            btnClear.Click += new System.EventHandler(this.btnClear_Click);
            btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            button1.Click += new System.EventHandler(this.button1_Click);
        }

        private readonly string connectionString = @"Data Source=LAPTOP-QNEEHTJU\SQLEXPRESS;Initial Catalog=Login;Integrated Security=True;Encrypt=False";

        private void Form10_Load(object sender, EventArgs e)
        {
            txtPetID.Text = GeneratePetID().ToString();
            LoadData();

            comboGender.DropDownStyle = ComboBoxStyle.DropDownList;

            dataGridView1.CellClick += DataGridView1_CellClick;
        }

        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];

                txtPetID.Text = row.Cells["Pet_ID"].Value.ToString();
                txtType.Text = row.Cells["Pet_Type"].Value.ToString();
                txtName.Text = row.Cells["Name"].Value.ToString();
                txtAge.Text = row.Cells["Age"].Value.ToString();
                comboGender.Text = row.Cells["Gender"].Value.ToString();
                txtDisability.Text = row.Cells["Disability"].Value.ToString();
                txtLocation.Text = row.Cells["Location"].Value.ToString();
                txtCharacteristics.Text = row.Cells["Characterisitics"].Value.ToString();
                txtUseName.Text = row.Cells["User_Name"].Value.ToString();
                txtNICNumber.Text = row.Cells["NIC"].Value.ToString();
                txtTelNumber.Text = row.Cells["Telephone_Number"].Value.ToString();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int pet_ID = GeneratePetID();
            string type = txtType.Text.Trim();
            string name = txtName.Text.Trim();
            string age = txtAge.Text.Trim();
            string gender = comboGender.Text.Trim();
            string disability = txtDisability.Text.Trim();
            string location = txtLocation.Text.Trim();
            string characteristics = txtCharacteristics.Text.Trim();
            string username = txtUseName.Text.Trim();
            string nicnumber = txtNICNumber.Text.Trim();
            string telnumber = txtTelNumber.Text.Trim();


            if (string.IsNullOrWhiteSpace(type) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(age) || string.IsNullOrEmpty(gender) || string.IsNullOrWhiteSpace(disability) || string.IsNullOrWhiteSpace(location) || string.IsNullOrEmpty(characteristics) || string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(nicnumber) || string.IsNullOrEmpty(telnumber))
            {
                MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            string query = "INSERT INTO Rescue_Pet_Table (Pet_ID, Pet_Type, Name, Age, Gender, Disability, Location, Characterisitics, User_Name, NIC, Telephone_Number) " +
            "VALUES (@Pet_ID, @Pet_Type, @Name, @Age, @Gender, @Disability, @Location, @Characterisitics, @User_Name, @NIC, @Tel_Number)";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Pet_ID", pet_ID);
                    cmd.Parameters.AddWithValue("@Pet_Type", type);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Age", age);
                    cmd.Parameters.AddWithValue("@Gender", gender);
                    cmd.Parameters.AddWithValue("@Disability", disability);
                    cmd.Parameters.AddWithValue("@Location", location);
                    cmd.Parameters.AddWithValue("@Characterisitics", characteristics);
                    cmd.Parameters.AddWithValue("@User_Name", username);
                    cmd.Parameters.AddWithValue("@NIC", nicnumber);
                    cmd.Parameters.AddWithValue("@Tel_Number", telnumber);

                    try
                    {
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        LoadData();
                        ClearForm();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        private int GeneratePetID()
        {
            return GetMaxID() + 1;
        }

        private int GetMaxID()
        {
            int maxID = 0;
            string query = "SELECT MAX(Pet_ID) FROM Rescue_Pet_Table";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    try
                    {
                        conn.Open();
                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            maxID = Convert.ToInt32(result);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }

            return maxID;
        }

        private void LoadData()
        {
            string query = "SELECT * FROM Rescue_Pet_Table";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        private void ClearForm()
        {
            txtPetID.Text = GeneratePetID().ToString(); // Reset Pet ID
            txtType.Clear();
            txtName.Clear();
            txtAge.Clear();
            comboGender.SelectedIndex = -1;
            txtDisability.Clear();
            txtLocation.Clear();
            txtCharacteristics.Clear();
            txtUseName.Clear();
            txtNICNumber.Clear();
            txtTelNumber.Clear();
            txtType.Focus(); // Set focus back to the first field
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtPetID.Text, out int petID))
            {
                string type = txtType.Text.Trim();
                string name = txtName.Text.Trim();
                string age = txtAge.Text.Trim();
                string gender = comboGender.Text.Trim();
                string disability = txtDisability.Text.Trim();
                string location = txtLocation.Text.Trim();
                string characteristics = txtCharacteristics.Text.Trim();
                string username = txtUseName.Text.Trim();
                string nicnumber = txtNICNumber.Text.Trim();
                string telnumber = txtTelNumber.Text.Trim();


                if (string.IsNullOrWhiteSpace(type) || string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(age) || string.IsNullOrEmpty(gender) || string.IsNullOrWhiteSpace(disability) || string.IsNullOrWhiteSpace(location) || string.IsNullOrEmpty(characteristics) || string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(nicnumber) || string.IsNullOrEmpty(telnumber))
                {
                    MessageBox.Show("Please fill in all required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Update existing pet record in the database
                string query = "UPDATE Rescue_Pet_Table SET Pet_Type = @Pet_Type, Name = @Name, Age = @Age, Gender = @Gender, Disability = @Disability, Location = @Location, Characterisitics = @Characterisitics, User_Name = @User_Name, NIC = @NIC, Telephone_Number = @Tel_Number WHERE Pet_ID = @Pet_ID";

                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@Pet_ID", petID);
                        cmd.Parameters.AddWithValue("@Pet_Type", type);
                        cmd.Parameters.AddWithValue("@Name", name);
                        cmd.Parameters.AddWithValue("@Age", age);
                        cmd.Parameters.AddWithValue("@Gender", gender);
                        cmd.Parameters.AddWithValue("@Disability", disability);
                        cmd.Parameters.AddWithValue("@Location", location);
                        cmd.Parameters.AddWithValue("@Characterisitics", characteristics);
                        cmd.Parameters.AddWithValue("@User_Name", username);
                        cmd.Parameters.AddWithValue("@NIC", nicnumber);
                        cmd.Parameters.AddWithValue("@Tel_Number", telnumber);

                        try
                        {
                            conn.Open();
                            cmd.ExecuteNonQuery();
                            LoadData();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid Pet ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                int selectedRowIndex = dataGridView1.SelectedRows[0].Index;
                int petID = Convert.ToInt32(dataGridView1.Rows[selectedRowIndex].Cells["Pet_ID"].Value);

                DialogResult dialogResult = MessageBox.Show("Are you sure you want to delete this pet?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (dialogResult == DialogResult.Yes)
                {
                    // Delete the selected pet record from the database
                    string deleteQuery = "DELETE FROM Rescue_Pet_Table WHERE Pet_ID = @petID";

                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, conn))
                        {
                            cmd.Parameters.AddWithValue("@petID", petID);

                            try
                            {
                                conn.Open();
                                cmd.ExecuteNonQuery();
                                dataGridView1.Rows.RemoveAt(selectedRowIndex);
                                ResequencePetIDs();
                                LoadData();
                                MessageBox.Show("Pet deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error deleting pet: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            finally
                            {
                                conn.Close();
                            }
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ResequencePetIDs()
        {
            List<int> remainingIDs = new List<int>();
            string getIDsQuery = "SELECT Pet_ID FROM Rescue_Pet_Table ORDER BY Pet_ID";

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(getIDsQuery, conn))
                {
                    try
                    {
                        conn.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                remainingIDs.Add(Convert.ToInt32(reader["Pet_ID"]));
                            }
                        }

                        int newID = 1;
                        foreach (int oldID in remainingIDs)
                        {
                            string updateQuery = "UPDATE Rescue_Pet_Table SET Pet_ID = @newID WHERE Pet_ID = @oldID";
                            using (SqlCommand updateCmd = new SqlCommand(updateQuery, conn))
                            {
                                updateCmd.Parameters.AddWithValue("@newID", newID);
                                updateCmd.Parameters.AddWithValue("@oldID", oldID);
                                updateCmd.ExecuteNonQuery();
                            }
                            newID++;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error re-sequencing Pet IDs: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 form5 = new Form5();
            form5.Show();
            this.Hide();
        }

        private void label14_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}