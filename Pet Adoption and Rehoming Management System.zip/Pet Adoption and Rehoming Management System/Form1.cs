﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace loadingBar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-QNEEHTJU\SQLEXPRESS;Initial Catalog=Login;Integrated Security=True;Encrypt=False");
        private void label6_Click(object sender, EventArgs e)
        {
            Form7 form7 = new Form7();
            form7.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String username, password, role;
            username = textBox1.Text;
            password = textBox2.Text;

            try
            {
                String query = "SELECT * FROM User_Table_PetAdoption WHERE username = @Username AND password = @Password";
                SqlDataAdapter sda = new SqlDataAdapter(query, conn);
                sda.SelectCommand.Parameters.AddWithValue("@Username", username);
                sda.SelectCommand.Parameters.AddWithValue("@Password", password);

                DataTable dataTable = new DataTable();
                sda.Fill(dataTable);

                if (dataTable.Rows.Count > 0 )
                {
                    role = dataTable.Rows[0]["Role"].ToString();

                    switch (role.ToLower())
                    {
                        case "admin":
                            Form6 form6 = new Form6();
                            form6.Show();
                            break;

                        case "guest":
                            Form14 form14 = new Form14();
                            form14.Show();
                            break;

                        case "user":
                            Form3 form3 = new Form3();
                            form3.Show();
                            break;

                        default:
                            MessageBox.Show("Unknown user", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            break;
                    }
                    this.Hide();

                }
                else
                {
                    MessageBox.Show("Invalid Username or Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
