﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace loadingBar
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-QNEEHTJU\SQLEXPRESS;Initial Catalog=Login;Integrated Security=True;Encrypt=False");

        private void Form6_Load(object sender, EventArgs e)
        {
            ReadData();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            NewData();
            ReadData();
            ClearForm();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            Update();
            ReadData();
            ClearForm();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            Delete();
            ReadData();
            ClearForm();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
        }

        public void ReadData()
        {
            try
            {
                conn.Open();
                string querry = "SELECT * FROM User_Table_PetAdoption";
                SqlDataAdapter adapter = new SqlDataAdapter(querry, conn);

                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: + ex.Message");
            }
            finally
            {
                conn.Close();
            }
        }
        public void NewData()
        {
            int userID;
            string name = txtName.Text;
            string username = txtUserName.Text;
            string password = txtPassword.Text;
            string Role = txtRole.Text;

            if(!int.TryParse(txtUserID.Text, out userID))
            {
                MessageBox.Show("Invalid Input");
                return;
            }

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(username) ||
        string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(Role))
            {
                MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                conn.Open();

                string query = "INSERT INTO User_Table_PetAdoption (UserID,Name,username,Password,Role) VALUES (@UseriD, @Name, @Username, @Password, @Role)";

                using (SqlCommand command = new SqlCommand(query, conn)) 
                {
                    command.Parameters.AddWithValue("@UserID", userID);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@Role", Role);

                    command.ExecuteNonQuery();

                    MessageBox.Show("User Successfully Added");
                }
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
            finally 
            { 
                conn.Close( );
            }
        }

        public void ClearForm()
        {
            txtUserID.Clear();
            txtName.Clear();
            txtUserName.Clear();
            txtPassword.Clear();
            txtRole.Clear();
        }

        
private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
       {
            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.Rows.Count)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                string UserID = selectedRow.Cells["UserID"].Value.ToString();
                string name = selectedRow.Cells["Name"].Value.ToString();
                string Username = selectedRow.Cells["Username"].Value.ToString();
                string password = selectedRow.Cells["Password"].Value.ToString();
                string role = selectedRow.Cells["Role"].Value.ToString();

                txtUserID.Text = UserID;
                txtName.Text = name;
                txtUserName.Text = Username;
                txtPassword.Text = password;
                txtRole.Text = role;
            }

        }

        private void Update()
        {
            int userID;
            string name = txtName.Text;
            string username = txtUserName.Text;
            string password = txtPassword.Text;
            string Role = txtRole.Text;

            if (!int.TryParse(txtUserID.Text, out userID))
            {
                MessageBox.Show("Invalid Input");
                return;
            }
            try
            {
                conn.Open();
                string query = "UPDATE User_Table_PetAdoption SET UserID = @UserID, Name = @Name, Username = @Username, Password = @Password, Role = @Role WHERE UserID = @UserID";

                using (SqlCommand comm = new SqlCommand(query, conn)) 
                {
                    comm.Parameters.AddWithValue("@UserID", userID);
                    comm.Parameters.AddWithValue("@Name", name);
                    comm.Parameters.AddWithValue("@Username", username);
                    comm.Parameters.AddWithValue("@Password", password);
                    comm.Parameters.AddWithValue("@Role", Role);

                    comm.ExecuteNonQuery();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error: + ex.Message");
            }
            finally
            {
                conn.Close();
            }
        }

        private void Delete()
        {
            string userID = txtUserID.Text;
            

            try
            {
                conn.Open();
                string query = "DELETE User_Table_PetAdoption WHERE UserID = @UserID";

                using(SqlCommand comm = new SqlCommand(query,conn))
                {
                    comm.Parameters.AddWithValue("@UserID", userID);

                    comm.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: + ex.Message");
            }
            finally
            {
                conn.Close();
            }
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            this.WindowState=FormWindowState.Minimized;
        }

       

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
    }
    
}