﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace loadingBar
{
    public partial class Form9 : Form
    {
        private static int billNumber = 0;
        private DataTable dt = new DataTable();
        private DataView dv;

        public Form9()
        {
            InitializeComponent();
            GenerateBillNumber();
        }

        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-QNEEHTJU\SQLEXPRESS;Initial Catalog=Login;Integrated Security=True;Encrypt=False");

        private void Form9_Load(object sender, EventArgs e)
        {
            LoadCombo();
            comboBox1.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            comboBox1.AutoCompleteSource = AutoCompleteSource.ListItems;

            printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(printDocument1_PrintPage);
            printDocument1.EndPrint += new System.Drawing.Printing.PrintEventHandler(printDocument1_EndPrint);

            // Initialize DataTable with necessary columns
            dt.Columns.Add("Pet_Name", typeof(string));
            dt.Columns.Add("Name_of_the_Donator", typeof(string));
            dt.Columns.Add("Amount", typeof(double));

            dv = new DataView(dt);
            dataGridView1.DataSource = dv;
        }

        private void LoadCombo()
        {
            try
            {
                conn.Open();
                string query = "SELECT * FROM Table_Donation";
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable comboDt = new DataTable();
                sda.Fill(comboDt);

                comboBox1.DataSource = comboDt;
                comboBox1.DisplayMember = "Pet_Name";
                comboBox1.ValueMember = "Pet_ID";
                comboBox1.SelectedIndex = -1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex != -1 && ((DataTable)comboBox1.DataSource).Rows.Count > 0)
            {
                DataRow dr = ((DataRowView)comboBox1.SelectedItem).Row;
                textBox2.Text = dr["Pet_Owner"].ToString();
                textBox1.Text = dr["Bank_Acount"].ToString();
                textBox3.Text = dr["Bank"].ToString();
                textBox4.Text = dr["Branch"].ToString();
            }
            else
            {
                textBox2.Text = string.Empty;
                textBox1.Text = string.Empty;
                textBox3.Text = string.Empty;
                textBox4.Text = string.Empty;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string petname = comboBox1.Text;
            string donator = textBox5.Text;

            if (double.TryParse(textBox6.Text, out double amount))
            {
                dt.Rows.Add(petname, donator, amount);
            }
            else
            {
                MessageBox.Show("Please enter a valid amount.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            CalculateTotalPrice();
            ClearAdd();
        }

        private void ClearAdd()
        {
            comboBox1.SelectedIndex = -1;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox6.Clear();
        }

        private void CalculateTotalPrice()
        {
            double sum = 0;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells["Amount"].Value != null && double.TryParse(row.Cells["Amount"].Value.ToString(), out double amount))
                {
                    sum += amount;
                }
            }
            lblAmount.Text = $"Total: Rs.{sum:F2}";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.Remove(row);
                }
                CalculateTotalPrice();
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            dt.Clear();
            ClearTextboxes();
            CalculateTotalPrice();
        }

        private void ClearTextboxes()
        {
            comboBox1.SelectedIndex = -1;
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
        }

        private void GenerateBillNumber()
        {
            billNumber++;
            label7.Text = $"Bill No: {billNumber}";
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            Image image = Properties.Resources.shutterstock_1128546527;
            e.Graphics.DrawImage(image, 320, 20, 200, 80);

            e.Graphics.DrawString("Invoice", new Font("Arial", 20, FontStyle.Bold), Brushes.Black, new Point(25, 150));

            e.Graphics.DrawString("Date: " + DateTime.Now.ToShortDateString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 180));

            e.Graphics.DrawString("Customer Name: " + textBox5.Text, new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 210));
            e.Graphics.DrawString(label7.Text, new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, 240));

            int y = 280;

            e.Graphics.DrawString("No", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(26, y));
            e.Graphics.DrawString("Pet Name", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(101, y));
            e.Graphics.DrawString("Name of the Donator", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(301, y));
            e.Graphics.DrawString("Amount", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(635, y));

            y += 30;

            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, y));

            y += 15;

            int No = 1;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                string petname = row.Cells["Pet_Name"].Value?.ToString();
                string donator = row.Cells["Name_of_the_Donator"].Value?.ToString();
                string amount = row.Cells["Amount"].Value?.ToString();

                e.Graphics.DrawString(No.ToString(), new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(26, y));
                e.Graphics.DrawString(petname, new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(101, y));
                e.Graphics.DrawString(donator, new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(301, y));
                e.Graphics.DrawString(amount, new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(635, y));

                No++;
                y += 25;
            }

            e.Graphics.DrawString("------------------------------------------------------------------------------------------------------------------", new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(25, y));
            y += 25;

            e.Graphics.DrawString(lblAmount.Text, new Font("Arial", 15, FontStyle.Regular), Brushes.Black, new Point(630, y));
        }

        private void printDocument1_EndPrint(object sender, System.Drawing.Printing.PrintEventArgs e)
        {
            MessageBox.Show("Print successfully...", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            GenerateBillNumber();
            try
            {
                printPreviewDialog1.ShowDialog();
                MessageBox.Show("Print Successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while printing: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            PrintInvoice();
        }

        private void PrintInvoice()
        {
            try
            {
                PrintDialog pd = new PrintDialog();
                pd.Document = printDocument1;
                if (pd.ShowDialog() == DialogResult.OK)
                {
                    printDocument1.Print();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while printing: {ex.Message}", "Print Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            dv.RowFilter = $"Pet_Name LIKE '%{textBox7.Text}%' OR Name_of_the_Donator LIKE '%{textBox7.Text}%' OR Convert(Amount, 'System.String') LIKE '%{textBox7.Text}%'";
        }

        private void label9_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.Show();
            this.Hide();
        }
        
        // Minimize the window
        private void pictureBox11_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        // Maximize the window
        private void pictureBox10_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        // Close the window
        private void pictureBox12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
